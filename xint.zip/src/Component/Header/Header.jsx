
import {
    Link
} from "react-router-dom";

import {
    AppBar,
    Box,
    Toolbar,
    Typography,
    Stack,
    Drawer,
    List,
    ListItem,
    ListItemButton,
    ListItemText,
    ListItemIcon,
    IconButton
} from "@mui/material";

import { deepPurple } from '@mui/material/colors';
import { grey } from '@mui/material/colors';
import { cyan } from '@mui/material/colors';

import {
    useState,
    useEffect
} from "react";

const Header = () => {

    const [openDrawer, setOpenDrawer] = useState(false);
    const [positionNavbar, setPositionNavbar] = useState("static");
    const [animateScroll, setAnimateScroll] = useState("");

    const ButtonInnerCmp = [
        {
            title: "Json Api",
            link: "/",
            icon: "account_circle",

        },
        {
            title: "Video Streaming Techniques",
            link: "/video-streaming",
            icon: "video_settings",

        },
        {
            title: "React Animations",
            link: "/react-animation",
            icon: "animation",

        },
        {
            title: "User",
            link: "/user",
            icon: "group",

        },
        {
            title: "Register",
            link: "/register-user",
            icon: "grid_view"
        },
        {
            title: "Login",
            link: "/login",
            icon: "login"
        }
    ];

    const ListCmp = ({ data }) => {
        const listDesign = (
            <>
                <ListItem disablePadding>
                    <ListItemButton sx={{
                        color: "inherit",
                        '&:hover': {
                            color: "white"
                        }
                    }
                    } component={Link} to={data.link}>
                        <ListItemIcon>
                            <span className="material-icons-outlined text-white">{data.icon}</span>
                        </ListItemIcon>
                        <ListItemText sx={{ fontFamily: 'Parisienne' }} primary={data.title} />
                    </ListItemButton>
                </ListItem>

            </>
        );
        return listDesign;
    }

    useEffect(() => {
        window.onscroll = () => {
            if (window.scrollY > 200) {
                return (
                    setAnimateScroll("animate__animated animate__slideInDown"),
                    setPositionNavbar("fixed")
                );
            }
            else {
                return (
                    setAnimateScroll("animate__animated animate__fadeInDown"),
                    setPositionNavbar("static")
                );
            }
        }
    }, [positionNavbar, animateScroll]);

    const design = (
        <>
            <Drawer sx={{ backgroundColor: cyan[500] }} onClick={() => setOpenDrawer(!openDrawer)} open={openDrawer} anchor="bottom" variant="temporary" sx={{
                width: "100%",
                "& .MuiDrawer-paper": {
                    width: "100%",
                    background: grey[800],
                    color: "white",
                }
            }}>
                <List>
                    {
                        ButtonInnerCmp.map((data, index) => {
                           return <ListCmp key={index} data={data} />
                        })
                    }
                </List>
            </Drawer>

            <Box>
                <AppBar  className={animateScroll+" animate__animated animate__fadeInDown"} position={positionNavbar} sx={{ backgroundColor: grey[200],color:grey[900] }}>
                    <Stack direction="row" justifyContent="space-between">
                        <Toolbar>
                            <Typography variant="h5" sx={{ fontFamily: 'Parisienne' }}>Mateen Ali</Typography>
                        </Toolbar>
                        <Toolbar>
                            <IconButton color="inherit" onClick={() => setOpenDrawer(!openDrawer)}>
                                <span className="material-icons">format_align_right</span>
                            </IconButton>
                        </Toolbar>
                    </Stack>
                </AppBar>
            </Box>
        </>
    );
    return design;
}
export default Header;