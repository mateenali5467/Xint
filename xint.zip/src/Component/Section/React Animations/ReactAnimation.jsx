import {
    Grid,
    Item
} from "@mui/material";

const ReactAnimation = ()=>{
 const design = (
     <>
        <div className="container mt-4">
           <div className="row">
           
             <div className="col-md-8">
                <img  src="images/mateen_poster.jpg"  width="100%" height="550px" />
             </div>
             <div className="col-md-4">
                <img src="images/mateen_welcome.jpeg"  width="100%"  height="550px" />
             </div>
           </div>
         
        </div>
     </>
 );
 return design;
}
export default ReactAnimation;