
import {
    TextField,
    Button,
    Box,
    Typography,
    Stack
  } from "@mui/material";
  
  import useHttp from "../../../Http/useHttp";
  import SweetAlert from 'react-bootstrap-sweetalert';
  import LoadingButton from '@mui/lab/LoadingButton';

  import {
      useState,
      useEffect
   } from "react";

    let loading = false;
const Login = ()=>{
    const signupForm = {
        email: "eve.holt@reqres.in",
        password: "cityslicka"
    }
    
     const [input,setInput] = useState(signupForm);
     const [requestApi,setRequestApi] = useState(null);
     const [httpResponse,httpError] = useHttp(requestApi);
     const [sweetAlert,setSweetAlert] = useState({
        state: false,
        title: "gfdgfd",
        icon: "default",
        message: ""
      });
    

 const submitForm = (e)=>{
    e.preventDefault();
    loading = true;
     return setRequestApi( {
        method : "post",
        url : "https://reqres.in/api/login",
        data : input
      });
     
 }
 console.log(httpResponse);
 useEffect(()=>{
    if(httpResponse)
    {
       loading = false;
        return setSweetAlert({
            state: true,
            title: "Good Job",
            icon: "success",
            message: "Login Successfull"
          });
     }
     if(httpError){
        return setSweetAlert({
            state: true,
            title: "Login Failed",
            icon: "error",
            message: "Login Failed"
          });
     }
 },[httpResponse,httpError]);

const handleInput = (e)=>{
  const input = e.target;
  const key = input.name;
  const value = input.value;
  return setInput((oldData)=>{
       return {
         ...oldData,
         [key] : value
       }
  });
}


const Alert = ()=>{
    const alert = (
      <>
        <SweetAlert
          show={sweetAlert.state}
          title={sweetAlert.title}
          type={sweetAlert.icon}
          customButtons={
            <>
              <Button onClick={()=>setSweetAlert({state:false})} variant="outlined" color="warning" sx={{ py:1, mr: 2 }}>Cancel</Button>
            </>
          }
          onConfirm={()=>{}}
        >
          {sweetAlert.message}
        </SweetAlert>
      </>
    );
    return alert;
  }

    const design = (
        <>
        <div className="container mt-5">
          <div className="row">
              <div className="col-md-7">
             
              <img  src="images/eastwood-sign-in.png" width="100%"  alt="dsad" />
              </div>
              <div className="col-md-5 mb-5">
           
                <Typography sx={{fontFamily : 'Parisienne'}} variant="h3" color="secondary">Login</Typography>
              <br></br>
                  <form onSubmit={submitForm}>
                  <Stack direction="column" spacing={2}>
                     <TextField  
                            type="string"
                            label="Email"
                            variant="filled"
                            name="email"
                            value={input.email}
                            onInput={handleInput}
                          />
                      <TextField 
                        type="string"
                        label="Password"
                        variant="filled"
                        name="password"
                        value={input.password}
                        onInput={handleInput}
                      />
                      <Stack direction="row" justifyContent="end">
                         <div>
                           <LoadingButton loading={loading} type="submit" variant="outlined">Login</LoadingButton>
                         </div>
                      </Stack>
                  </Stack>
                  </form>
              
                 
              </div>
              
          </div>
          <Alert />
        </div>
        </>
    );
    return design;
   }
   export default Login;