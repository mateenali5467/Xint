import Header from "./Header";
import {
    Outlet
} from "react-router-dom";

const NavbarCmp = () => {
    const design = (
        <>
            <Header />
            <Outlet />
        </>
    );
    return design;
}
export default NavbarCmp;