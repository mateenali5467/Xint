

import "./Json.css";

import {
  useState,
  useEffect
} from "react";

import useHttp from "../../../Http/useHttp";

import { purple } from '@mui/material/colors';
import { deepPurple } from '@mui/material/colors';
import { blueGrey } from '@mui/material/colors';
import { Typography } from "@mui/material";


import {
    Skeleton,
    Button,
    Stack,
    Card,
    CardContent,
    CardActions,
    CardMedia,
    Box,
    Pagination 
} from "@mui/material";

const JsonUser = ()=>{

    const [apiStartData,setApiStartData] = useState(0);
    const[apiEndData,setApiEndData] = useState(12);
    const [animation,setAnimation] = useState("animate__animated animate__slideInRight"); 

    const requestAPi = {
        method : "get",
        url :   `https://jsonplaceholder.typicode.com/photos?_start=${apiStartData}&_limit=${apiEndData}`
     }

    const [request,setRequest] = useState(requestAPi);
    const [httpResponse,httpError] = useHttp(request);

    const arrowRightFn = ()=>{
        return (
          setApiStartData(apiStartData+12),
          setRequest({
              method : "get",
              url : `https://jsonplaceholder.typicode.com/photos?_start=${apiStartData+12}&_limit=${apiEndData}`
            }),
            setAnimation("animate__animated animate__slideInRight")
        );
    }

    const arrowLeftFn = ()=>{
      return (
        setAnimation("animate__animated animate__slideInLeft"),
        setApiStartData((apiStartData-12)),
        setRequest({
            method : "get",
            url : `https://jsonplaceholder.typicode.com/photos?_start=${(apiStartData-12)}&_limit=${apiEndData}`
          })
          
      ); 
  }

 const MaterialUiCard = ({data})=>{
     const design = (
         <>
            <div className={"col-md-4"}>
                <Card className="mb-2 mt-4 ">
                      <CardMedia
                      component="img"
                      height="140"
                      image={data.thumbnailUrl}
                      alt="Thumnail_Pic"
                    /> 
                    <CardContent>
                      <Typography gutterBottom variant="h5" component="div" className="apiData">
                        {
                            data.title.substring(0,25)
                        }
                      </Typography>
                    </CardContent>
                </Card>
            </div>
      
         </>
     );
     return design;
 }

const apiString = request.url.toString();
const apiRemoveQ = apiString.replaceAll(/"/g,"");

const NextAndPrevBtn = ({mt,mb})=>{
  const design  = (
    <>
        <Stack className={"mt-"+mt+" mb-"+mb} direction="row" justifyContent="end" alignItems="center">
                  <Box>
                    <Button disabled={apiStartData === 0 ? true : false }  color="secondary" variant="outlined" onClick={arrowLeftFn }>Prev</Button>
                    <Button disabled={true}>{apiStartData+1} - {apiStartData+12}</Button>
                    <Button color="secondary" variant="outlined" onClick={arrowRightFn }>Next</Button>
                  </Box>
              </Stack>
    </>
  );
  return design;
}

useEffect(()=>{},[request,animation,apiStartData]);

 const design = (
        <>

          <div className="container ">
            <Typography variant="h3" className="mb-3 mt-4" sx={{color:deepPurple[700],fontFamily : 'Parisienne'}} >Json Api</Typography>
            <Typography  variant="p" className="apiData" sx={{color:deepPurple[700]}}>
              https://jsonplaceholder.typicode.com/
              <br/>
              
              {
                 apiRemoveQ.split('/')[3]
              }
            </Typography>
           
           {
             httpResponse ?  <NextAndPrevBtn mt="4" mb="1"  /> : null
           }
         
             <div className={"row overflow-hidden "+animation}>
            
                {
                    httpResponse ? httpResponse.data.map((data,index)=>{
                        return <MaterialUiCard data={data} key={index} />
                    }) : <Skeleton sx={{ bgcolor: blueGrey[100] }} variant="rectangular" width="100%" height="300px" />
                } 
              
             </div>

              {
                httpResponse ?  <NextAndPrevBtn mt="2" mb="5"  /> : null
              }

          </div>
        </>
    );
    return design;
   }
   export default JsonUser;