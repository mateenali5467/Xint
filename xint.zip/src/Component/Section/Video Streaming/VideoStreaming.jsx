const VideoStreaming = ()=>{
  const design = (
      <>
          <h1>Welcome to Video Streaming Website</h1>
          <p>Please w8 deploy after one month</p>
      </>
  );
  return design;
}
export default VideoStreaming;