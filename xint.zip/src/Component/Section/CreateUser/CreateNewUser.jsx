
import "./CreateUser.css";
import {
  TextField,
  Button,
  Box,
  Typography,
  Stack
} from "@mui/material";

import LoadingButton from '@mui/lab/LoadingButton';

import useHttp from "../../../Http/useHttp";
import SweetAlert from 'react-bootstrap-sweetalert';

import {
  useState,
  useEffect
} from "react";

let loader = false;

const CreateNewUser = () => {
  const signupForm = {
    name: "eve.morpheus@reqres.in",
    job: "leader"
  }

  const [input, setInput] = useState(signupForm);
  const [requestApi, setRequestApi] = useState(null);
  const [httpResponse, httpError, finallyState] = useHttp(requestApi);
  const [sweetAlert, setSweetAlert] = useState({
    state: false,
    title: "gfdgfd",
    icon: "default",
    message: ""
  });


  const submitForm = (e) => {
    e.preventDefault();
    loader = true;
    return setRequestApi({
      method: "post",
      url: "https://reqres.in/api/users",
      data: input
    });
  }

  useEffect(() => {
    if (httpResponse) {
      loader = false;
      return setSweetAlert({
        state: true,
        title: "Good Job",
        icon: "success",
        message: "Create User Successfull"
      });

    }
    if (httpError) {
      return setSweetAlert({
        state: true,
        title: "User Create Failed",
        icon: "error",
        message: "Failed"
      });
    }

  }, [httpResponse, httpError, finallyState]);


  const Alert = () => {
    const alert = (
      <>
        <SweetAlert
          show={sweetAlert.state}
          title={sweetAlert.title}
          type={sweetAlert.icon}
          customButtons={
            <>
              <Button onClick={() => setSweetAlert({ state: false })} variant="outlined" color="warning" sx={{ py: 1, mr: 2 }}>Cancel</Button>
            </>
          }
          onConfirm={() => { }}
        >
          {sweetAlert.message}
        </SweetAlert>
      </>
    );
    return alert;
  }



  const design = (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-3"></div>
          <div className="col-md-6 mt-3">
            <Typography sx={{ fontFamily: 'Parisienne' }} variant="h3" color="secondary">Create User</Typography>
            <br></br>
            <form onSubmit={submitForm}>
              <Stack direction="column" spacing={2}>
                <TextField
                  type="string"
                  label="Name"
                  variant="standard"
                  name="name"
                  value={input.name}
                />
                <TextField
                  type="string"
                  label="Job"
                  variant="standard"
                  name="job"
                  value={input.job}
                />
                <Stack direction="row" justifyContent="end">
                  <div className="d-flex">
                    <LoadingButton loading={loader} type="submit" variant="outlined">Create User</LoadingButton>
                  </div>

                </Stack>
              </Stack>

            </form>
          </div>
          <div className="col-md-3">

          </div>
        </div>
        <Alert />
      </div>
    </>
  );
  return design;
}
export default CreateNewUser;