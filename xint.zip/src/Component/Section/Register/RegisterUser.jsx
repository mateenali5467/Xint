
import "./regitser.css";
import {
  TextField,
  Button,
  Box,
  Typography,
  Stack
} from "@mui/material";

import useHttp from "../../../Http/useHttp";
import SweetAlert from 'react-bootstrap-sweetalert';
import LoadingButton from '@mui/lab/LoadingButton';

import {
  useState,
  useEffect
} from "react";

let loading = false;

const RegisterUser = () => {

  const signupForm = {
    email: "eve.holt@reqres.in",
    password: "pistol"
  }

  const [input, setInput] = useState(signupForm);
  const [requestApi, setRequestApi] = useState(null);
  const [httpResponse, httpError] = useHttp(requestApi);
  console.log(httpResponse);
  const [sweetAlert, setSweetAlert] = useState({
    state: false,
    title: "",
    icon: "default",
    message: ""
  });

  const submitForm = (e) => {
    e.preventDefault();
    loading = true;
    return setRequestApi({
      method: "post",
      url: "https://reqres.in/api/register",
      data: input
    });
   
  }
  useEffect(() => {
    if (httpResponse) {
      loading = false;
      if (httpResponse.status === 200) {
        return setSweetAlert({
          state: true,
          title: "Register Successfull",
          icon: "success",
          message: "UserToken " + httpResponse.data.token
        });
      }
    }
    if (httpError) {
      loading = false;
      if (httpError.status === 400) {
        return setSweetAlert({
          state: true,
          title: "Register Failed",
          icon: "error",
          message: httpError.data.error
        });
      }
      return setSweetAlert({
        state: true,
        title: "Register Failed",
        icon: "error",
        message: httpError.data.error
      });
    
    }
  }, [httpResponse, httpError]);


  const Alert = () => {
    const alert = (
      <>
        <SweetAlert
          show={sweetAlert.state}
          title={sweetAlert.title}
          type={sweetAlert.icon}
          customButtons={
            <>
              <Button onClick={() => setSweetAlert({ state: false })} variant="outlined" color="warning" sx={{ py: 1, mr: 2 }}>Cancel</Button>

            </>
          }
          onConfirm={() => { }}
        >
          {sweetAlert.message}
        </SweetAlert>
      </>
    );
    return alert;
  }

  const changeFn = (e) => {
    const input = e.target;
    const key = input.name;
    const value = input.value;
    return setInput((oldData) => {
      return {
        ...oldData,
        [key]: value
      }
    })
  }
  const design = (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-7">
            <img src="images/clip-sign-in.png" width="100%" alt="sign" />
          </div>
          <div className="col-md-5 mt-md-5">
            <Typography sx={{ fontFamily: 'Parisienne' }} variant="h3" color="secondary">Register</Typography>
            <br></br>
            <form onSubmit={submitForm}>
              <Stack direction="column" spacing={2}>
                <TextField
                  type="string"
                  label="Email"
                  variant="outlined"
                  name="email"
                  value={input.email}
                  onInput={changeFn}

                />
                <TextField
                  type="string"
                  label="Password"
                  variant="outlined"
                  name="password"
                  value={input.password}
                  onInput={changeFn}

                />
                <Stack direction="row" justifyContent="end">
                  <div>
                    <LoadingButton loading={loading} variant="contained" type="submit">Register</LoadingButton>
                  </div>
                </Stack>
              </Stack>

            </form>
          </div>

        </div>
        <Alert />



      </div>
    </>
  );
  return design;
}
export default RegisterUser;