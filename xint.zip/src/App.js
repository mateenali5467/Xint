import "./App.css";
import * as React from "react";
import 'material-icons/iconfont/material-icons.css';
import 'animate.css';
import {
  CircularProgress
} from "@mui/material";

import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";

const Header = React.lazy(() => import("./Component/Header/Header"));
const User = React.lazy(() => import("./Component/Section/User/User"));
const Login = React.lazy(() => import("./Component/Section/Login/Login"));
const RegisterUser = React.lazy(() => import("./Component/Section/Register/RegisterUser"));
const NavbarCmp = React.lazy(() => import("./Component/Header/NavbarCmp"));
const CreateNewUser = React.lazy(() => import("./Component/Section/CreateUser/CreateNewUser"));
const JsonUser = React.lazy(() => import("./Component/Section/JsonUser/JsonUser"));
const VideoStreaming = React.lazy(() => import("./Component/Section/Video Streaming/VideoStreaming"));
const ReactAnimation =  React.lazy(() => import("./Component/Section/React Animations/ReactAnimation"));

const App = () => {

  const Loader = () => {
    const l = (
      <>
        <CircularProgress color="info" className="loader" />
      </>
    );
    return l;
  }

  const design = (
    <>
      <Router>
        <React.Suspense fallback={<Loader />}>
          <NavbarCmp />
        </React.Suspense>
        <Routes>
          <Route path="/" element={
            <React.Suspense fallback={<Loader />}>
              <JsonUser />
            </React.Suspense>
          } />
          <Route path="/login" element={<React.Suspense fallback={<Loader />}>
            <Login />
          </React.Suspense>} />
          <Route path="/register-user" element={<React.Suspense fallback={<Loader />}>
            <RegisterUser />
          </React.Suspense>} />
          <Route path="/create-user" element={<React.Suspense fallback={<Loader />}>
            <CreateNewUser />
          </React.Suspense>} />

          <Route path="/user" element={<React.Suspense fallback={<Loader />}>
            <User />
          </React.Suspense>} />


          <Route path="/video-streaming" element={<React.Suspense fallback={<Loader />}>
            <VideoStreaming />
          </React.Suspense>} />

          <Route path="/react-animation" element={<React.Suspense fallback={<Loader />}>
            <ReactAnimation />
          </React.Suspense>} />

        </Routes>
      </Router>
    </>
  );
  return design;

}
export default App;