import axios from "axios";
import {
  useState,
  useEffect
} from "react";

const useHttp = (request) => {

  const [httpResponse, setHttpResponse] = useState(null);
  const [httpError, setHttpError] = useState(null);
  const [finallyState, setFinally] = useState(true);

  const Ajax = () => {
    axios(request)
      .then((response) => {
        setHttpResponse(response);
      })
      .catch((error) => {
        setHttpError(error.response);
      }).
      finally(() => {
        setFinally(false);
      });
  }
  useEffect(() => {
    if (request) {
      Ajax();
    }
  }, [request]);

  return [httpResponse, httpError, finallyState];

}
export default useHttp;
