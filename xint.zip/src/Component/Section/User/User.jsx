import axios from "axios";
import useHttp from "../../../Http/useHttp";

import {
  useState,
  useEffect
} from "react";

import { purple } from '@mui/material/colors';
import { deepPurple } from '@mui/material/colors';
import { Typography } from "@mui/material";

import {
    Skeleton,
    Button,
    Stack,
    Pagination 
} from "@mui/material";

const User = ()=>{

    const [counterNextPage,setCounterNextpage] = useState(1);

    const requestAPi = {
        method : "get",
        url : "https://reqres.in/api/users?page="+counterNextPage
     }

    const [request,setRequest] = useState(requestAPi);
    const [httpResponse,httpError] = useHttp(request);
    
    if(httpResponse){
        var totalPages = httpResponse.data.total_pages;
        var currentPage = httpResponse.data.page;
        console.log(httpResponse);
    }

    const arrowRightFn = ()=>{
        return setRequest({
            method : "get",
            url : "https://reqres.in/api/users?page="+(counterNextPage-1)
        });
    }

    const arrowLeftFn = ()=>{
        return setRequest({
            method : "get",
            url : "https://reqres.in/api/users?page="+(counterNextPage+1)
        });
        
    }
    const handleChange = (event,value) => {
        return setRequest({
            method : "get",
            url : "https://reqres.in/api/users?page="+(value)
        });
      };

 const design = (
        <>
           <div className="container">
            <div className="row">
            <div className="col-md-12">
            <Typography variant="h3" sx={{color:deepPurple[700],fontFamily : 'Parisienne'}} className="mt-5 mb-3">User List</Typography>
            <div className="d-flex justify-content-end mb-4">
              <Pagination count={totalPages} color="primary" onChange={handleChange}  />
            </div>
           {
               httpResponse ?  <table style={{width:"100%"}} className="table-responsive w-100 d-block d-md-table table   table-light table-striped table-hover table-borderless animate__animated animate__fadeIn animate__delay-0.5s">
                <thead>
                <tr style={{color:purple[500],fontSize:"18px"}}>
                    <th>#</th>
                    <th>Image</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                </tr>
                </thead>
                <tbody>
                 {
                    httpResponse.data.data.map((data,index)=>{
                        return <tr key={index}>
                        <td>{data.id}</td>
                        <td><img width="50px" style={{borderRadius:"50px"}} src={data.avatar}></img></td>
                            <td>{data.first_name}</td>
                            <td>{data.last_name}</td>
                            <td>{data.email}</td> 
                        </tr>
                    }) 
                 }
                </tbody>
            </table>  : <Skeleton variant="rectangular" width="100%" height="500px" />
           } 
            <Stack className="mb-4" direction="row" justifyContent="end" spacing={1}>
                <Button disabled={currentPage === 1 ? true : null} onClick={arrowRightFn}>
                  <span className="material-icons">keyboard_double_arrow_left</span>
                </Button>
                <Button disabled={totalPages === currentPage ? true : null} onClick={arrowLeftFn}>
                  <span className="material-icons">keyboard_double_arrow_right</span>
                </Button>
            </Stack>
            
            </div>
            </div>
           </div> 
        </>
    );
    return design;
   }
   export default User;